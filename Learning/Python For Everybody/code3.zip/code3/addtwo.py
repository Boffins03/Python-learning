def addtwo(a, b):
    added = a + b
    return added

x = addtwo(3, 5)
print(x)
